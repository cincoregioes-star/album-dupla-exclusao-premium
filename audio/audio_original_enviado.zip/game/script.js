const STORAGE_KEY="../index.html".includes("x")?"x":"album_dupla_exclusao_municipal_36_v1";
const tab=document.getElementById("tabuleiro");
const icons=["●","▲","■","★","⬢","◆"];
function render(){
  tab.innerHTML=Array.from({length:36},()=>`<div class="cel">${icons[Math.floor(Math.random()*icons.length)]}</div>`).join("");
}
function carregar(){
  try{return JSON.parse(localStorage.getItem(STORAGE_KEY))||{album:{},pacotes:2,repetidas:0,historico:[],simuladosFeitos:[]}}catch(e){return {album:{},pacotes:2,repetidas:0,historico:[],simuladosFeitos:[]}}
}
function salvar(e){localStorage.setItem(STORAGE_KEY,JSON.stringify(e))}
function reg(e,num){const id="fig-"+String(num).padStart(2,"0"); if(!e.album[id]) e.album[id]={quantidade:0,colada:false}; return e.album[id]}
function escolher(e){
  const faltando=[];
  for(let n=1;n<=36;n++){const r=reg(e,n); if(!r.colada && r.quantidade===0) faltando.push(n)}
  return faltando.length?faltando[Math.floor(Math.random()*faltando.length)]:Math.floor(Math.random()*36)+1;
}
function jogar(){
  render();
  const e=carregar();
  const n=escolher(e);
  const r=reg(e,n);
  if(r.quantidade>0||r.colada)e.repetidas=Number(e.repetidas||0)+1;
  r.quantidade++;
  e.historico=e.historico||[];
  e.historico.push({tipo:"game",numero:n,data:new Date().toISOString()});
  salvar(e);
  const n2=String(n).padStart(2,"0");
  document.getElementById("resultado").innerHTML=`<div class="premio"><h2>Figurinha desbloqueada!</h2><img src="../figurinhas/${n2}.webp"><p>Você ganhou a figurinha <b>${n2}</b>.</p><p>Ela já foi enviada para o álbum. Volte e clique em colar.</p></div>`;
}
render();
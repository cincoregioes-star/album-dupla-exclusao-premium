const STORAGE_KEY = "album_dupla_exclusao_municipal_36_v1";
let paginaAtual = Number(localStorage.getItem("pagina_municipal_36") || 1);

function estadoInicial(){
  return {
    album:{},
    pacotes:2,
    repetidas:0,
    historico:[],
    simuladosFeitos:[],
    desafioFeito:false,
    conclusaoRegistrada:false,
    codigoConfirmacao:null
  };
}
let estado = carregar();

function carregar(){
  try{
    return {...estadoInicial(), ...(JSON.parse(localStorage.getItem(STORAGE_KEY))||{})};
  }catch(e){return estadoInicial()}
}
function salvar(){
  localStorage.setItem(STORAGE_KEY, JSON.stringify(estado));
  atualizarStatus();
}
function reg(num){
  const id = "fig-"+String(num).padStart(2,"0");
  if(!estado.album[id]) estado.album[id]={quantidade:0,colada:false};
  return estado.album[id];
}
function abrirTela(nome){
  document.querySelectorAll(".tela").forEach(t=>t.classList.remove("ativa"));
  document.getElementById("tela-"+nome).classList.add("ativa");
  if(nome==="album") renderAlbum();
  if(nome==="simulados") renderSimulados();
  if(nome==="admin") carregarConcluintes();
}
function atualizarStatus(){
  document.getElementById("pacotesQtd").textContent = estado.pacotes;
  document.getElementById("repetidasQtd").textContent = estado.repetidas || 0;
  document.getElementById("coladasQtd").textContent = FIGURINHAS.filter(f=>reg(f.numero).colada).length;
}
function imgSrc(num){return `figurinhas/${String(num).padStart(2,"0")}.webp`}

function renderAlbum(){
  localStorage.setItem("pagina_municipal_36", paginaAtual);
  const p = PAGINAS[paginaAtual-1];
  document.getElementById("tituloPagina").textContent = `Página ${p.pagina} — ${p.titulo}`;
  document.getElementById("textoPagina").textContent = p.texto;

  const figs = FIGURINHAS.filter(f=>f.pagina===paginaAtual);
  const html = `<article class="pagina"><h2>${p.titulo}</h2><div class="texto-pagina">${p.texto}</div><div class="grid-fig">${figs.map(cardFig).join("")}</div></article>`;
  document.getElementById("albumPages").innerHTML = html;
  verificarConclusao();
  atualizarStatus();
}
function cardFig(f){
  const r=reg(f.numero);
  const tem = r.quantidade>0 || r.colada;
  if(!tem){
    return `<div class="fig-card bloqueada"><span class="badge">${f.raridade}</span><div class="fig-img">${String(f.numero).padStart(2,"0")}</div><button onclick="abrirFicha(${f.numero})">Bloqueada</button></div>`;
  }
  return `<div class="fig-card"><span class="badge">${f.raridade}</span><img src="${imgSrc(f.numero)}" alt="${f.titulo}"><button onclick="${r.colada?`abrirFicha(${f.numero})`:`colarFig(${f.numero})`}">${r.colada?"Ver ficha":"Colar figurinha"}</button></div>`;
}
function paginaAnterior(){ if(paginaAtual>1){paginaAtual--; renderAlbum()} }
function proximaPagina(){ if(paginaAtual<6){paginaAtual++; renderAlbum()} }

function abrirPacote(){
  if(estado.pacotes<=0){
    modal(`<h2>Sem pacotes</h2><p>Ganhe pacotes nos simulados ou jogando o game.</p><button class="btn" onclick="fecharModal()">Ok</button>`);
    return;
  }
  estado.pacotes--;
  const ganhas=[];
  for(let i=0;i<5;i++) ganhas.push(liberarFigurinha("pacote"));
  salvar();
  modal(`<h2>Pacote aberto</h2><p>Você ganhou estas figurinhas:</p><div class="grid-fig">${ganhas.map(n=>`<div class="fig-card"><img src="${imgSrc(n)}"><button>Figurinha ${String(n).padStart(2,"0")}</button></div>`).join("")}</div><button class="btn" onclick="fecharModal();abrirTela('album')">Ir para o álbum</button>`);
}
function liberarFigurinha(motivo){
  let disponiveis = FIGURINHAS.filter(f=>!reg(f.numero).colada && reg(f.numero).quantidade===0);
  let f = disponiveis.length ? disponiveis[Math.floor(Math.random()*disponiveis.length)] : FIGURINHAS[Math.floor(Math.random()*FIGURINHAS.length)];
  const r=reg(f.numero);
  if(r.quantidade>0 || r.colada) estado.repetidas = Number(estado.repetidas||0)+1;
  r.quantidade++;
  estado.historico.push({tipo:"figurinha",motivo,numero:f.numero,data:new Date().toISOString()});
  return f.numero;
}
function colarFig(num){
  const r=reg(num);
  if(r.quantidade<=0 || r.colada) return;
  r.quantidade--;
  r.colada=true;
  estado.historico.push({tipo:"colada",numero:num,data:new Date().toISOString()});
  salvar();
  renderAlbum();
  abrirFicha(num);
}
function abrirFicha(num){
  const f=FIGURINHAS.find(x=>x.numero===num);
  const r=reg(num);
  if(!r.colada){
    modal(`<h2>Ficha bloqueada</h2><p>Primeiro ganhe e cole esta figurinha no álbum.</p><button class="btn" onclick="fecharModal()">Fechar</button>`);
    return;
  }
  modal(`<h2>${String(num).padStart(2,"0")} — ${f.titulo}</h2><img class="premio-img" src="${imgSrc(num)}"><p><b>Tema:</b> ${f.tema}</p><p><b>Raridade:</b> ${f.raridade}</p><p>Esta figurinha ajuda a refletir sobre racismo, capacitismo, acessibilidade, respeito e inclusão na escola.</p><button class="btn" onclick="fecharModal()">Fechar</button>`);
}

const SIMULADOS = [
  {titulo:"Conceitos Básicos", premio:2, perguntas:[
    ["O que é capacitismo?",["Tratar pessoas com deficiência como incapazes","Construir rampas","Uma disciplina escolar","Um esporte"],0],
    ["O que é racismo estrutural?",["Desigualdade presente nas instituições","Uma brincadeira sem consequência","Uma prova difícil","Um conteúdo de matemática"],0],
    ["Dupla exclusão pode acontecer quando:",["Racismo e capacitismo atingem o mesmo estudante","O aluno recebe livros","A turma faz recreio","A escola pinta a parede"],0],
    ["Inclusão escolar garante:",["Acessibilidade, respeito e pertencimento","Separação dos alunos","Silêncio absoluto","Apenas notas altas"],0],
    ["Acessibilidade é:",["Direito","Favor","Privilégio","Castigo"],0],
    ["Representatividade significa:",["Ver diferentes pessoas valorizadas","Excluir histórias diversas","Mostrar um grupo só","Evitar debates"],0],
    ["Combater discriminação é dever:",["De toda a comunidade escolar","Só do aluno","Só da família","De ninguém"],0],
    ["A escola inclusiva deve:",["Adaptar e respeitar formas de aprender","Isolar estudantes","Ignorar Libras","Impedir participação"],0]
  ]},
  {titulo:"Situações na Escola", premio:2, perguntas:[
    ["Um aluno surdo sem Libras enfrenta falta de:",["Acessibilidade comunicacional","Uniforme","Prova","Recreio"],0],
    ["Bullying por raça ou deficiência deve ser tratado como:",["Discriminação séria","Brincadeira normal","Competição","Assunto sem importância"],0],
    ["Família e escola devem:",["Dialogar em parceria","Culpar o aluno","Evitar adaptações","Esconder dificuldades"],0],
    ["Colegas aliados ajudam quando:",["Acolhem e combatem exclusões","Riem do colega","Isolam o estudante","Reforçam apelidos"],0],
    ["Material adaptado serve para:",["Apoiar a aprendizagem","Facilitar injustamente","Separar alunos","Diminuir conteúdo sempre"],0],
    ["Baixa expectativa é ruim porque:",["Limita oportunidades","Ajuda o aluno","É inclusão","É avaliação"],0],
    ["Denunciar discriminação ajuda a:",["Proteger direitos","Criar problema","Punir sem ouvir","Evitar diálogo"],0],
    ["Professor mediador deve:",["Escutar e orientar","Ignorar conflitos","Expor aluno","Reforçar preconceito"],0]
  ]},
  {titulo:"Acessibilidade e Inclusão", premio:2, perguntas:[
    ["Tecnologia assistiva serve para:",["Ampliar autonomia","Substituir professor","Separar turma","Dar vantagem injusta"],0],
    ["Mobilidade na escola envolve:",["Rampas e caminhos acessíveis","Só recreio","Só pintura","Só uniforme"],0],
    ["Conselho escolar pode ajudar:",["Debatendo direitos e inclusão","Cancelando aulas","Separando alunos","Evitando família"],0],
    ["Cidade que respeita começa com:",["Escola que inclui","Silêncio","Exclusão","Competição"],0],
    ["Autonomia significa:",["Apoiar sem controlar","Fazer tudo pelo aluno","Ignorar necessidade","Impedir escolha"],0],
    ["Inclusão verdadeira acontece quando:",["Todos participam com dignidade","O aluno fica separado","Só alguns aprendem","Não há adaptação"],0],
    ["Racismo na escola pode aparecer em:",["Piadas e invisibilidade","Só em livros","Apenas na rua","Nunca acontece"],0],
    ["O projeto do álbum busca:",["Aprender, refletir e promover diálogo","Só colecionar imagens","Substituir aulas","Evitar debates"],0]
  ]}
];

function renderSimulados(){
  document.getElementById("simuladosArea").innerHTML = SIMULADOS.map((s,i)=>{
    const feito = estado.simuladosFeitos.includes(i);
    return `<div class="quiz-card"><h3>${s.titulo}</h3><p>8 questões. Recompensa: ${s.premio} pacotes.</p><button class="btn" ${feito?"disabled":""} onclick="iniciarSimulado(${i})">${feito?"Respondido":"Responder"}</button></div>`;
  }).join("") + `<div class="quiz-card"><h3>Desafio Final — Mestre da Inclusão</h3><p>10 questões difíceis. Recompensa: 10 figurinhas.</p><button class="btn" ${estado.desafioFeito?"disabled":""} onclick="iniciarDesafio()">Iniciar desafio</button></div>`;
}
function iniciarSimulado(i){
  let pos=0, acertos=0;
  const s=SIMULADOS[i];
  function tela(){
    const q=s.perguntas[pos];
    modal(`<h2>${s.titulo}</h2><p><b>${pos+1}/8.</b> ${q[0]}</p>${q[1].map((op,idx)=>`<button class="opcao" onclick="responderQuiz(${idx})">${"ABCD"[idx]}) ${op}</button>`).join("")}`);
  }
  window.responderQuiz=(idx)=>{
    if(idx===s.perguntas[pos][2]) acertos++;
    pos++;
    if(pos<s.perguntas.length) tela();
    else{
      estado.simuladosFeitos.push(i);
      estado.pacotes += s.premio;
      salvar();
      modal(`<h2>Resultado</h2><p>Você acertou ${acertos}/8.</p><p>Ganhou ${s.premio} pacotes.</p><button class="btn" onclick="fecharModal();renderSimulados()">Continuar</button>`);
    }
  }
  tela();
}
function iniciarDesafio(){
  const perguntas = [
    ["A dupla exclusão exige olhar para:",["Barreiras combinadas","Apenas notas","Só uniforme","Só recreio"],0],
    ["Uma escola antirracista precisa:",["Agir de forma permanente","Fazer ação isolada","Evitar debate","Culpar aluno"],0],
    ["Capacitismo pode estar em:",["Falas que diminuem a capacidade","Acessibilidade","Respeito","Autonomia"],0],
    ["Representatividade contribui para:",["Pertencimento","Silenciamento","Exclusão","Separação"],0],
    ["Acessibilidade comunicacional inclui:",["Libras e recursos visuais","Só rampa","Só prova","Só recreio"],0],
    ["Gestão comprometida deve:",["Planejar inclusão","Ignorar barreiras","Separar alunos","Evitar famílias"],0],
    ["Colegas aliados combatem:",["Bullying e discriminação","Aprendizagem","Acessibilidade","Participação"],0],
    ["Tecnologia assistiva promove:",["Autonomia","Dependência forçada","Exclusão","Silêncio"],0],
    ["Denunciar discriminação é:",["Proteção de direitos","Fofoca","Brincadeira","Competição"],0],
    ["Escola que inclui ajuda a construir:",["Cidade que respeita","Cidade que exclui","Prova mais difícil","Menos participação"],0],
  ];
  let pos=0, acertos=0;
  function tela(){
    const q=perguntas[pos];
    modal(`<h2>Desafio Final</h2><p><b>${pos+1}/10.</b> ${q[0]}</p>${q[1].map((op,idx)=>`<button class="opcao" onclick="responderDesafio(${idx})">${"ABCD"[idx]}) ${op}</button>`).join("")}`);
  }
  window.responderDesafio=(idx)=>{
    if(idx===perguntas[pos][2]) acertos++;
    pos++;
    if(pos<perguntas.length) tela();
    else{
      if(acertos===10){
        for(let i=0;i<10;i++) liberarFigurinha("desafio-final");
        estado.desafioFeito=true;
        salvar();
        modal(`<h2>Desafio vencido</h2><p>Você acertou 10/10 e ganhou 10 figurinhas.</p><button class="btn" onclick="fecharModal();abrirTela('album')">Ir para o álbum</button>`);
      }else{
        modal(`<h2>Tente novamente</h2><p>Você acertou ${acertos}/10. Para ganhar as 10 figurinhas, precisa acertar todas.</p><button class="btn" onclick="fecharModal()">Fechar</button>`);
      }
    }
  }
  tela();
}

function verificarConclusao(){
  const total=FIGURINHAS.filter(f=>reg(f.numero).colada).length;
  if(total===36 && !estado.conclusaoRegistrada){
    telaConclusao();
  }
}
function telaConclusao(){
  const codigo = estado.codigoConfirmacao || ("DX-"+Date.now().toString().slice(-6));
  estado.codigoConfirmacao = codigo;
  salvar();
  modal(`<div class="conclusao"><h2>Parabéns!</h2><p>Você completou o Álbum Digital Dupla Exclusão.</p><p><b>Código de confirmação:</b> ${codigo}</p><p>Mostre esta tela aos alunos apresentadores para concorrer ao álbum impresso.</p></div>
  <div class="form-final"><input id="nomeFinal" placeholder="Nome do participante"><input id="escolaFinal" placeholder="Escola, bairro ou cidade"><input id="whatsFinal" placeholder="WhatsApp opcional"></div>
  <button class="btn" onclick="registrarConclusao()">Registrar conclusão</button>`);
}
async function registrarConclusao(){
  const nome=document.getElementById("nomeFinal").value.trim();
  const escola=document.getElementById("escolaFinal").value.trim();
  const whats=document.getElementById("whatsFinal").value.trim();
  if(!nome){alert("Digite o nome.");return}
  const item={nome, escola_bairro:escola, whatsapp:whats, codigo_confirmacao:estado.codigoConfirmacao, total_figurinhas:36, album_completo:true, premio_entregue:false, created_at:new Date().toISOString()};
  let lista=JSON.parse(localStorage.getItem("concluintes_local")||"[]");
  if(!lista.some(x=>x.codigo_confirmacao===item.codigo_confirmacao)) lista.push(item);
  localStorage.setItem("concluintes_local", JSON.stringify(lista));
  estado.conclusaoRegistrada=true; salvar();

  if(SUPABASE_URL && SUPABASE_ANON_KEY){
    try{
      await fetch(`${SUPABASE_URL}/rest/v1/album_concluintes`,{
        method:"POST",
        headers:{apikey:SUPABASE_ANON_KEY,Authorization:`Bearer ${SUPABASE_ANON_KEY}`,"Content-Type":"application/json",Prefer:"return=minimal"},
        body:JSON.stringify(item)
      });
    }catch(e){console.warn("Supabase offline",e)}
  }
  modal(`<h2>Conclusão registrada</h2><p>Código: <b>${item.codigo_confirmacao}</b></p><p>Mostre aos apresentadores para conferência.</p><button class="btn" onclick="fecharModal()">Fechar</button>`);
}
function carregarConcluintes(){
  const lista=JSON.parse(localStorage.getItem("concluintes_local")||"[]");
  document.getElementById("listaConcluintes").innerHTML = lista.length ? lista.map((x,i)=>`<div class="linha-concluinte"><b>${i+1}</b><span>${x.nome}<br><small>${x.escola_bairro||""} • ${x.codigo_confirmacao}</small></span><button onclick="marcarPremio('${x.codigo_confirmacao}')">${x.premio_entregue?"Entregue":"Marcar"}</button></div>`).join("") : "<p>Nenhum concluinte registrado neste navegador.</p>";
}
function marcarPremio(cod){
  let lista=JSON.parse(localStorage.getItem("concluintes_local")||"[]");
  lista=lista.map(x=>x.codigo_confirmacao===cod?{...x,premio_entregue:true}:x);
  localStorage.setItem("concluintes_local", JSON.stringify(lista));
  carregarConcluintes();
}
function exportarConcluintes(){
  const lista=JSON.parse(localStorage.getItem("concluintes_local")||"[]");
  const csv=["nome,escola_bairro,whatsapp,codigo_confirmacao,created_at,premio_entregue"].concat(lista.map(x=>`"${x.nome}","${x.escola_bairro||""}","${x.whatsapp||""}","${x.codigo_confirmacao}","${x.created_at}","${x.premio_entregue}"`)).join("\n");
  const a=document.createElement("a");
  a.href=URL.createObjectURL(new Blob([csv],{type:"text/csv"}));
  a.download="concluintes_album.csv"; a.click();
}
function confirmarReinicio(){
  if(confirm("Tem certeza que deseja reiniciar todo o álbum neste navegador?")){
    localStorage.removeItem(STORAGE_KEY);
    estado=estadoInicial();
    paginaAtual=1;
    salvar();
    renderAlbum();
  }
}
function modal(html){document.getElementById("modalConteudo").innerHTML=html;document.getElementById("modal").classList.remove("oculto")}
function fecharModal(){document.getElementById("modal").classList.add("oculto")}
function init(){
  atualizarStatus();
  abrirTela("projeto");
}
init();
